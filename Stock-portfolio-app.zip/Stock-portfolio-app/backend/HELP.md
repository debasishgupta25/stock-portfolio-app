# Stock Portfolio Management Application
# Developed in Gradle Java SpringBoot

### Steps to start the server:
1. Gradle clean, 
2. Gradle build,
3. Run StockApplication

### URL: http://localhost:8080/api/v1/stock

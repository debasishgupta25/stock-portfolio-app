import { Stock } from './stock.model';

describe('Stock', () => {
  it('should create an instance', () => {
    expect(new Stock()).toBeTruthy();
  });
});

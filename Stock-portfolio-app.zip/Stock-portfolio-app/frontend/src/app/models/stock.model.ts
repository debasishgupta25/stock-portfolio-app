export class Stock {
  id?: any;
  name?: any;
  symbol?: string;
  quantity?: number;
  price?: string;
}